# Importing essential libraries and modules

from flask import Flask, render_template, request, Markup
import numpy as np
import pandas as pd

import requests
import config
import pickle
import io


from flask import Flask, request, jsonify, render_template
import joblib


from  url_features  import extract_features

# Load the model from the file 
model = joblib.load('xg_boost_recomondation.pkl')  
# ==============================================================================================

# -------------------------LOADING THE TRAINED MODELS -----------------------------------------------

# Loading plant disease classification model

#disease_dic= ['5','6', '7', '8','9']



#from model_predict  import pred_leaf_disease

# ===============================================================================================
# ------------------------------------ FLASK APP -------------------------------------------------


app = Flask(__name__)

# render home page


@ app.route('/')
def home():
    title = 'Phishing URL Prediction Using Machine learning'
    return render_template('index.html', title=title)

# render crop recommendation form page

@app.route('/disease-predict', methods=['GET', 'POST'])
def disease_prediction():
    title = 'Phishing URL Prediction Using Machine learning'

    if request.method == 'POST':
        # Get the image URL from the form
            int_features = [str(x) for x in request.form.values()]



            print(int_features[0])
        
              #  if not image_url:
              #      return render_template('disease.html', title=title, error="Please provide a valid image URL.")

                   # if not file:
                    #    return render_template('disease.html', title=title)
            #int_features = [str(x) for x in request.form.values()]


            #print(int_features)
            #a=int_features

            #url_processed = url_features.main(a[0])
            list_inputs=extract_features(int_features[0]) 
              
                


            url_processed =np.array([list_inputs])
            prediction=model.predict(url_processed)
            print(prediction)                                                                                                                                                                                              
    
            if prediction[0]==1:
                                  prediction_text='This is a Phishing Website'
            else:
                                  prediction_text='This is is a legitimate Website'





            return render_template('rust-result.html', prediction=prediction_text,title=title)
        #except:
         #   pass
    return render_template('rust.html', title=title)


# render disease prediction result page


# ===============================================================================================
if __name__ == '__main__':
    app.run(debug=True)
